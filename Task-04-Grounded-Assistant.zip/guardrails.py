from assistant import GroundedAssistant

def check_question(question):
    """
    Returns the guardrail category:
    None, unsafe, or off_topic.
    """
    assistant = object.__new__(GroundedAssistant)
    return assistant.guardrail(question)
