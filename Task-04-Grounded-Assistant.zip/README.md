# Task 04 – Capstone: Grounded College Assistant

## Project Overview

This capstone project is a grounded college-information assistant designed to stay inside a clearly defined remit.

The assistant can answer questions about the college using the provided document, refuses off-topic requests, blocks unsafe requests, reports when information is not available in the documents, and measures token usage for every interaction.

## Requirements Covered

### 1. Guardrails

The assistant has three important boundaries:

- **College-information scope:** It answers questions related to the supplied college knowledge base.
- **Off-topic guardrail:** It refuses unrelated requests.
- **Unsafe-request guardrail:** It refuses requests involving harmful or unauthorized activity.

Examples:

```text
Write a Python program.
→ I'm a College Information Assistant...
```

```text
How can I hack someone's account?
→ I can't help with harmful or unauthorized activities...
```

### 2. Evaluation Set

The file `evaluation/evaluation_set.csv` contains 10 test cases covering:

- grounded questions
- information not present in documents
- off-topic requests
- unsafe requests

Run:

```bash
python evaluator.py
```

The evaluator creates:

```text
evaluation/evaluation_results.csv
```

It reports:

- total tests
- passed tests
- failed tests
- percentage score
- measured tokens
- estimated cost

### 3. Token / Cost Measurement

The project measures approximate input and output tokens using whitespace-token counting.

This is a lightweight measurement suitable for this local capstone. It is not a provider billing tokenizer.

No paid LLM API is used, so the estimated API cost is:

```text
$0.00
```

The measured token counts are still recorded in the evaluation results.

## Technology Stack

- Python
- Streamlit
- Sentence Transformers
- FAISS
- NumPy

## Project Structure

```text
Task-04-Grounded-Assistant/
│
├── app.py
├── assistant.py
├── guardrails.py
├── evaluator.py
├── requirements.txt
├── README.md
│
├── documents/
│   └── college_info.txt
│
├── evaluation/
│   ├── evaluation_set.csv
│   └── evaluation_results.csv
│
└── screenshots/
```

## How to Run

### Step 1 – Open the project

Open this folder in VS Code.

### Step 2 – Install dependencies

```bash
pip install -r requirements.txt
```

### Step 3 – Run the assistant

```bash
streamlit run app.py
```

### Step 4 – Run evaluation

Open another terminal and run:

```bash
python evaluator.py
```

The evaluation results will be saved to:

```text
evaluation/evaluation_results.csv
```

## Evaluation Scoring

Each test receives:

- `1` = Passed
- `0` = Failed

The score is:

```text
Score = Passed Tests / Total Tests × 100
```

The evaluation set intentionally includes both normal and adversarial-style requests so that the assistant can be evaluated beyond simple factual questions.

## Grounding Workflow

```text
User Question
      ↓
Guardrail Check
      ↓
Safe + In Scope?
   /          \
 No            Yes
 ↓              ↓
Refuse       Embed Question
                ↓
          FAISS Retrieval
                ↓
        Relevant Passages
                ↓
          Grounded Answer
                ↓
        Source + Usage Data
```

## Design Decisions

This project intentionally uses a local retrieval-based architecture instead of a paid generative API.

This makes the capstone:

- reproducible
- low cost
- easy to run
- easy to evaluate
- focused on grounding and guardrails

The answer is taken from retrieved document content, which reduces the risk of inventing unsupported information.

## Suggested Screenshots for Submission

Take screenshots of:

1. A normal grounded college question and its source.
2. An off-topic request being refused.
3. An unsafe request being refused.
4. The evaluation summary in the terminal.
5. The `evaluation_results.csv` file showing scores and token usage.

## GitHub Submission

Create a **public GitHub repository**, upload the complete project, and submit the repository URL.

Suggested repository name:

```text
task-04-grounded-college-assistant
```
