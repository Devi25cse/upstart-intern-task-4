import streamlit as st
from assistant import GroundedAssistant

st.set_page_config(page_title="Grounded College Assistant", page_icon="🎓")

st.title("🎓 Grounded College Assistant")
st.caption("Answers only within its college-information remit.")

@st.cache_resource
def get_assistant():
    return GroundedAssistant("documents/college_info.txt")

assistant = get_assistant()

st.info(
    "Scope: college information, departments, technical activities, "
    "Skill Development Cell and related information in the provided document."
)

question = st.text_input("Ask a question:")

if st.button("Ask"):
    if not question.strip():
        st.warning("Please enter a question.")
    else:
        result = assistant.answer(question)

        st.subheader("Answer")
        st.write(result["answer"])

        if result["guardrail"]:
            st.warning(f"Guardrail: {result['guardrail']}")

        st.subheader("Source")
        if result["sources"]:
            for source in result["sources"]:
                st.info(source)
        else:
            st.write("No source passage used.")

        st.subheader("Usage")
        st.write(f"Input tokens: {result['input_tokens']}")
        st.write(f"Output tokens: {result['output_tokens']}")
        st.write(f"Total tokens: {result['total_tokens']}")
        st.write(f"Estimated API cost: ${result['estimated_cost_usd']:.6f}")

st.divider()
st.caption("Evaluation-ready capstone: guardrails + grounded answers + usage measurement.")
