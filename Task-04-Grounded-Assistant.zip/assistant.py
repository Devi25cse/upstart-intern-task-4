from pathlib import Path
import re
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

MODEL_NAME = "all-MiniLM-L6-v2"

OFF_TOPIC_PATTERNS = [
    "recipe", "movie", "song", "football", "cricket", "stock price",
    "weather", "dating", "relationship", "travel itinerary",
    "write a poem", "write a story", "python program", "c++ program"
]

UNSAFE_PATTERNS = [
    "hack someone's account", "hack an account", "steal password",
    "bypass password", "phishing attack", "malware",
    "ransomware", "keylogger", "ddos attack", "break into"
]

COLLEGE_TERMS = [
    "college", "department", "cse", "student", "skill development",
    "workshop", "technical", "engineering", "program", "course",
    "activity", "event", "coding", "project", "campus"
]

class GroundedAssistant:
    def __init__(self, document_path):
        self.model = SentenceTransformer(MODEL_NAME)
        self.text = Path(document_path).read_text(encoding="utf-8")
        self.chunks = self.chunk_text(self.text)

        embeddings = self.model.encode(
            self.chunks,
            convert_to_numpy=True,
            normalize_embeddings=True
        ).astype("float32")

        self.index = faiss.IndexFlatIP(embeddings.shape[1])
        self.index.add(embeddings)

    def chunk_text(self, text, chunk_size=80, overlap=20):
        words = text.split()
        chunks = []
        start = 0

        while start < len(words):
            end = min(start + chunk_size, len(words))
            chunk = " ".join(words[start:end]).strip()
            if chunk:
                chunks.append(chunk)

            if end == len(words):
                break

            start = end - overlap

        return chunks

    def estimate_tokens(self, text):
        # Simple reproducible approximation: whitespace tokens.
        return len(re.findall(r"\S+", text))

    def guardrail(self, question):
        q = question.lower()

        for pattern in UNSAFE_PATTERNS:
            if pattern in q:
                return "unsafe"

        has_college_term = any(term in q for term in COLLEGE_TERMS)
        has_off_topic = any(pattern in q for pattern in OFF_TOPIC_PATTERNS)

        if has_off_topic and not has_college_term:
            return "off_topic"

        return None

    def answer(self, question):
        guardrail = self.guardrail(question)

        if guardrail == "unsafe":
            answer = (
                "I can't help with harmful or unauthorized activities. "
                "I can help with safe cybersecurity concepts instead."
            )
            return self.result(answer, [], question, guardrail)

        if guardrail == "off_topic":
            answer = (
                "I'm a College Information Assistant. I can help only with "
                "college-related information from the provided knowledge base."
            )
            return self.result(answer, [], question, guardrail)

        query_embedding = self.model.encode(
            [question],
            convert_to_numpy=True,
            normalize_embeddings=True
        ).astype("float32")

        k = min(3, len(self.chunks))
        scores, ids = self.index.search(query_embedding, k)

        sources = []
        for score, idx in zip(scores[0], ids[0]):
            if idx >= 0 and float(score) >= 0.35:
                sources.append(self.chunks[idx])

        if not sources:
            answer = "I don't have enough information in the provided college documents to answer that."
            return self.result(answer, [], question, "not_in_documents")

        # Small-build grounded response: use the strongest retrieved passage.
        answer = sources[0]
        return self.result(answer, sources, question, None)

    def result(self, answer, sources, question, guardrail):
        input_tokens = self.estimate_tokens(question)
        output_tokens = self.estimate_tokens(answer)
        total_tokens = input_tokens + output_tokens

        # No paid API is used in this project.
        estimated_cost_usd = 0.0

        return {
            "answer": answer,
            "sources": sources,
            "guardrail": guardrail,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "estimated_cost_usd": estimated_cost_usd
        }
