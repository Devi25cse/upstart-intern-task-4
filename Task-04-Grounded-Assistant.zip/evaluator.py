import csv
from assistant import GroundedAssistant

INPUT_FILE = "evaluation/evaluation_set.csv"
OUTPUT_FILE = "evaluation/evaluation_results.csv"

assistant = GroundedAssistant("documents/college_info.txt")

results = []

with open(INPUT_FILE, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for row in reader:
        result = assistant.answer(row["question"])

        actual = result["answer"]
        expected_type = row["expected_type"]

        if expected_type == "grounded":
            passed = bool(result["sources"])
        elif expected_type == "not_in_documents":
            passed = result["guardrail"] == "not_in_documents"
        elif expected_type == "off_topic":
            passed = result["guardrail"] == "off_topic"
        elif expected_type == "unsafe":
            passed = result["guardrail"] == "unsafe"
        else:
            passed = False

        results.append({
            "id": row["id"],
            "question": row["question"],
            "expected_type": expected_type,
            "actual": actual,
            "score": 1 if passed else 0,
            "input_tokens": result["input_tokens"],
            "output_tokens": result["output_tokens"],
            "total_tokens": result["total_tokens"],
            "estimated_cost_usd": result["estimated_cost_usd"]
        })

with open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=results[0].keys())
    writer.writeheader()
    writer.writerows(results)

total = len(results)
passed = sum(r["score"] for r in results)
percentage = (passed / total * 100) if total else 0
total_tokens = sum(r["total_tokens"] for r in results)
total_cost = sum(r["estimated_cost_usd"] for r in results)

print("=== Evaluation Summary ===")
print(f"Total tests: {total}")
print(f"Passed: {passed}")
print(f"Failed: {total - passed}")
print(f"Score: {percentage:.1f}%")
print(f"Total measured tokens: {total_tokens}")
print(f"Estimated API cost: ${total_cost:.6f}")
print(f"Results saved to: {OUTPUT_FILE}")
