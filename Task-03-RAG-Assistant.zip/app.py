import streamlit as st
from rag import build_index, answer_question

st.set_page_config(page_title="Document Q&A - RAG Assistant", page_icon="📚")

st.title("📚 Document Q&A – RAG Assistant")
st.write("Ask questions from the provided document. Answers are based only on the document.")

@st.cache_resource
def load_rag():
    return build_index("documents/college_info.txt")

index_data = load_rag()

question = st.text_input("Ask a question:")

if st.button("Ask"):
    if not question.strip():
        st.warning("Please enter a question.")
    else:
        result = answer_question(question, index_data)

        st.subheader("Answer")
        st.write(result["answer"])

        st.subheader("Retrieved Source Passage")
        if result["sources"]:
            for i, source in enumerate(result["sources"], 1):
                st.info(f"Source {i}: {source}")
        else:
            st.write("No relevant source passage found.")
