# Task 03 – Retrieval-Augmented Answers

## Project Title
Document Q&A – RAG Assistant

## Objective
This project demonstrates a small Retrieval-Augmented Generation (RAG) style document question-answering system.

The application answers questions using information retrieved from the user's own document instead of relying on general model memory.

## What this project includes

- Document loading
- Document chunking
- Text embeddings
- FAISS vector search
- Relevant passage retrieval
- Answer display
- Retrieved source passage display
- Honest "Not found in the documents." response
- Streamlit user interface

## Project Structure

```text
Task-03-RAG-Assistant/
│
├── app.py
├── rag.py
├── requirements.txt
├── README.md
│
├── documents/
│   └── college_info.txt
│
└── screenshots/
```

## Technologies Used

- Python
- Streamlit
- Sentence Transformers
- FAISS
- NumPy

## How to Run

### 1. Install Python

Make sure Python 3.10 or later is installed.

### 2. Open the project in VS Code

Open the `Task-03-RAG-Assistant` folder.

### 3. Open the terminal

Run:

```bash
pip install -r requirements.txt
```

### 4. Start the application

Run:

```bash
streamlit run app.py
```

The application will open in the browser.

## Example Test 1

Question:

```text
Where is the college located?
```

Expected result:

```text
Sir Isaac Newton College of Engineering and Technology is located in Pappakovil, Nagapattinam.
```

The retrieved source passage is displayed below the answer.

## Example Test 2

Question:

```text
What does the Computer Science and Engineering department focus on?
```

Expected result:

The application retrieves the relevant passage about programming, databases, artificial intelligence and cybersecurity.

## Example Test 3 – Information Not in Documents

Question:

```text
What is the hostel fee?
```

Expected result:

```text
Not found in the documents.
```

This demonstrates that the application does not invent an answer when the requested information is not present in the document.

## RAG Workflow

```text
Document
   ↓
Text Extraction
   ↓
Chunking
   ↓
Embeddings
   ↓
FAISS Vector Index
   ↓
User Question
   ↓
Question Embedding
   ↓
Similarity Search
   ↓
Relevant Passages
   ↓
Answer + Source Passage
```

## Design Decision

For this small build, the retrieved passage itself is used as the answer instead of adding an external paid LLM API. This keeps the project simple, reproducible and focused on the required retrieval workflow.

## Submission

Push this project to a **public GitHub repository** and submit the repository URL.
