from pathlib import Path
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

MODEL_NAME = "all-MiniLM-L6-v2"
model = SentenceTransformer(MODEL_NAME)

def load_document(path):
    return Path(path).read_text(encoding="utf-8")

def chunk_text(text, chunk_size=80, overlap=20):
    words = text.split()
    chunks = []
    start = 0

    while start < len(words):
        end = min(start + chunk_size, len(words))
        chunk = " ".join(words[start:end]).strip()
        if chunk:
            chunks.append(chunk)

        if end == len(words):
            break

        start = end - overlap

    return chunks

def build_index(path):
    text = load_document(path)
    chunks = chunk_text(text)

    embeddings = model.encode(
        chunks,
        convert_to_numpy=True,
        normalize_embeddings=True
    ).astype("float32")

    index = faiss.IndexFlatIP(embeddings.shape[1])
    index.add(embeddings)

    return {
        "chunks": chunks,
        "index": index
    }

def answer_question(question, data, top_k=3, threshold=0.35):
    query_embedding = model.encode(
        [question],
        convert_to_numpy=True,
        normalize_embeddings=True
    ).astype("float32")

    k = min(top_k, len(data["chunks"]))
    scores, ids = data["index"].search(query_embedding, k)

    selected = []
    for score, idx in zip(scores[0], ids[0]):
        if idx >= 0 and float(score) >= threshold:
            selected.append((float(score), data["chunks"][idx]))

    if not selected:
        return {
            "answer": "Not found in the documents.",
            "sources": []
        }

    # This small-build version answers by returning the most relevant
    # retrieved passage instead of using an external LLM.
    best_score, best_chunk = selected[0]

    return {
        "answer": best_chunk,
        "sources": [chunk for _, chunk in selected]
    }
